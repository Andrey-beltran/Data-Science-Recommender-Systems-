# Gorse Recommender System

Este es un motor de recomendaciones basado en el proyecto open source **[Gorse](https://github.com/zhenghaoz/gorse)**.

## 🔍 ¿Qué es Gorse?

Gorse es un sistema de recomendaciones escalable escrito en Go, que permite sugerir productos, contenidos o servicios basado en comportamiento de usuarios. Utiliza algoritmos colaborativos, contenido y reglas de negocio.

## ⚙️ ¿Qué incluye este repositorio?

- Código fuente original de Gorse
- Configuraciones listas para levantar con Docker (`docker-compose.yml`)
- Carpetas organizadas: `server`, `worker`, `client`, `model`, entre otras
- Listo para pruebas locales o personalización

## 🚀 ¿Cómo ejecutarlo?

1. Instala Docker y Docker Compose en tu equipo.
2. Clona este repositorio.
3. Ejecuta en terminal:

```bash
docker-compose up
```

4. Accede a la interfaz: [http://localhost:8088](http://localhost:8088)

## 📦 Próximos pasos

- Cargar datasets personalizados
- Integrar con aplicaciones externas (API REST)
- Personalizar con modelos de Machine Learning propios

## 🙌 Autor

Este repositorio fue adaptado por Andrey Beltrán como parte del desarrollo de un módulo de recomendaciones para Keos.

---

