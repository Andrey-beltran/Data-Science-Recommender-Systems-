GOAT has been moved to https://github.com/gorse-io/goat
